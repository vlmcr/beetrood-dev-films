import React from "react"

const HomePage = ({isLoading}) => <h1>Home Page {isLoading}</h1>

export default HomePage