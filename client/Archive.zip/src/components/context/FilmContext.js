import {createContext} from "react"

const FilmContext = createContext()
export default FilmContext
